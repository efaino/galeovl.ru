<?php
/**
 * Footer Template
 *
 * @version 4.6.2
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

 		/**
		* @hooked virtue_footer_markup - 10
		*/
		do_action( 'virtue_footer' );
		?>
		</div><!--Wrapper-->

<a href="#x" class="overlay" id="zapis"></a>
  <div class="popup">
	  <div class="form_title">Записаться на процедуру</div>
    <?php echo do_shortcode('[forminator_form id="2022"]'); ?>
    <a class="closer" title="Закрыть" href="#close"><i class="icon-close"></i></a>
  </div>



		<?php wp_footer(); ?>

	</body>
</html>