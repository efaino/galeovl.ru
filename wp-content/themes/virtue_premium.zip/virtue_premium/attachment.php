<?php
/**
 * Single Attachment
 *
 * @package Virtue Theme
 */

get_template_part( 'templates/content', 'attachment' );
