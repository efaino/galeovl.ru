<?php
/**
 * Single Staff Post.
 *
 * @package Virtue Theme
 */

get_template_part( 'templates/content', 'singlestaff' );
